// ****************************************************************************************************
// LEDS are mapped as follows:
// PIN - LED MAP
// LED1 = RA6 (ACTIVE LOW)
// LED2 = RA7 (ACTIVE LOW)
// LED3 = RA0 (ACTIVE LOW)
// LED4 = RA1 (ACTIVE LOW)
// LED5 = RA2 (ACTIVE LOW)
// LED6 = RA3 (ACTIVE LOW)
// LED7 = RA4 (ACTIVE LOW)
// LED8 = MCLR (RA5) - it;sfucking with you, ted.
// LED9 = RB1 (ACTIVE LOW)
// LED10 =RB2 (ACTIVE LOW)
// LED11 =RB3 (ACTIVE LOW)
// LED12 =RB5 (ACTIVE LOW)
// LED13 =RB4 (ACTIVE LOW)
// LED14 =RB6 (ACTIVE HIGH)
// LED15 =RB7 (ACTIVE HIGH)
//
// ****************************************************************************************************
//TO DO
//Move button to RB0
//Sleep and wake up on change on PORTB  (RBIE interrupt enable RBIF interrupt flag)

#include <stdio.h>
#include <stdlib.h>
#include <pic16f648a.h>
#include <xc.h>
#include <stdint.h>

// CONFIG
#pragma config FOSC = INTOSCIO  // Oscillator Selection bits (INTOSC oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)#pragma config PWRTE = ON       // Power-up Timer Enable bit (PWRT enabled)
#pragma config MCLRE = OFF      // RA5/MCLR/VPP Pin Function Select bit (RA5/MCLR/VPP pin function is digital input, MCLR internally tied to VDD)
#pragma config BOREN = OFF      // Brown-out Detect Enable bit (BOD enabled)
#pragma config LVP = OFF        // Low-Voltage Programming Enable bit (RB4/PGM pin has digital I/O function, HV on MCLR must be used for programming)
#pragma config CPD = OFF        // Data EE Memory Code Protection bit (Data memory code protection off)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

#define _XTAL_FREQ = 4000000;

#define UP 1
#define DOWN 0
#define pinCount 15
#define pwmMax 100              // max 'ticks' in a cycle
// arbitrary starting direction
uint8_t direction = DOWN;
#define MAX_DEBOUNCE_COUNT 	50			// How many times do we need the changed state
#define BUTTON1     PORTBbits.RB0
#define BUTTONON 0
#define BUTTONOFF 1

uint8_t brightnessLEDS[pinCount];
uint8_t patternLarsonUP[pinCount];
uint8_t patternLarsonDOWN[pinCount];
uint8_t patternCurrent[pinCount];
uint8_t patternCurrentCopy[pinCount];

uint8_t buttonTest = 1; // instantaneous button state (to be debounced)
uint8_t buttonState = 1; // active low button (debounced output)
uint8_t buttonCounter = 0; // debounce counter
uint8_t buttonLock = 0;

uint8_t mode = 0;

uint8_t msCounter = 0;
uint8_t ms10Counter = 0;
uint8_t ms100Counter = 0;
uint8_t sCounter = 0;
uint8_t firstSetup = 0;

uint8_t duty = 0; // % of current cycle executed
uint8_t offset = 0;

enum mode {
    //    off, count, chase, larson, crazyeyes, fader, flicker, bright, dim, breather, larsonEyes
    off, count, chase, larson, fader, flicker, bright, dim, breather

};

// add modes
//- sparkle (set random leds high and decrment in loops
//- larson with eyes always on
//- mouth fader with eyes always on

#define maxMode 9

void setup(void);

void handlePWM(void);
void handlePattern(void);
void setupCountPattern(void);
void setupChasePattern(void);
void setupLarsonPattern(void);
void clearPattern(void);
void setupCrazyEyesPattern(void);
void setupAllFadePattern(void);
void setupBrightPattern(void);
void setupDimPattern(void);
void setupBreatherPattern(void);
void setupLevels(void);
void debounce(char test, char *state, char *counter);

void interrupt checkInterrupts(void) {
    if (T0IE && T0IF) //are TMR0 interrupts enabled and is the TMR0 interrupt flag set?
    {
        TMR0 = 5; // sets verflow to happen in 250 more ticks for an even 1ms interrupt
        T0IF = 0; //TMR0 interrupt flag must be cleared in software to allow subsequent interrupts
        ++msCounter;
        if (msCounter > 99) {
            ms100Counter++;
            msCounter = 0;
            sCounter++;
        }
    }
    if (INTE && INTF) {
        INTF = 0; // Clear RBO interrupt flag
    }
}

/*
 *
 */
void main(void) {

    setup();

    mode = off;

    while (1) {

        if (sCounter > 100) {
            mode++;
            firstSetup = 0;
            sCounter = 0;
            if (mode > maxMode) {
                mode = 0;
            }
        }

        //            //        buttonTest = BUTTON1;
        //            debounce(BUTTON1, &buttonState, &buttonCounter);
        //
        //            if ((buttonState == BUTTONON) && (buttonLock == 0)) {
        //                buttonLock = 1;
        //                mode++;
        //                firstSetup = 0;
        //                ms100Counter = 0;
        //                if (mode > maxMode) {
        //                    mode = 0;
        //                }
        //            }
        //            if ((buttonState == BUTTONOFF) && (buttonLock == 1)) {
        //                buttonLock = 0;
        //            }
        //
        if (duty < pwmMax) {
            handlePWM(); // Toggle pins as required based on values in brightness array
        } else {
            if (mode == off) {
                //                clearPattern();
                //                setupLevels();
                //                handlePWM();
                //                SLEEP(); // 100nA sleep mode!
                //                mode++; // change mode when waking from sleep, otherwise will wake, see it's sleep mode ande go back to sleep!
                firstSetup = 0;
                PORTA = 0xFF;
                PORTB = 0x3F;
            }
            if (mode == count) {
                setupCountPattern();
            }
            if (mode == chase) {
                setupChasePattern();
            }
            if (mode == larson) {
                setupLarsonPattern();
            }
            if (mode == fader) {
                setupAllFadePattern();
            }
            if (mode == flicker) {
                setupAllFadePattern();
            }
            if (mode == bright) {
                setupBrightPattern();
            }
            if (mode == dim) {
                setupDimPattern();
            }
            if (mode == breather) {
                setupBreatherPattern();
            }
            setupLevels(); // Copy selected array to brightness array to implement PWM
        }
    }
}

void setup(void) {
    //SETUP IO PORTS
    TRISA = 0x20; // All PORTA pins are outputs, except MCLR (RA5)
    CMCON = 0x07; // Comparators off, allows digital IO on RA[0..3]
    TRISB = 0x00; // All pins are outputs.
    PORTA = 0xFF;
    PORTB = 0x3F;
    //SET UP OPTION REGISTER
    OPTION_REG = 0x81; //disEnable weak pullups PORTB, 1:4 prescaler TMR0 (4us ticks), RB0 interrupt on falling edge
    //ENABLE INTERRUPTS
    //    INTCON = 0xA0; // Global Interrupts Enabled (GIE), TMR0 Overflow Interrupt Enabled (T0IE)
    INTCON = 0xB0; // Global Interrupts Enabled (GIE), TMR0 Overflow Interrupt Enabled (T0IE), RBO interrupt enabled

//    mode = off;
//    firstSetup = 0;

    for (int i = 0; i++; i < pinCount) {

        brightnessLEDS[i] = 0;
    }
    // setup Larson Scanner patterns
    patternLarsonUP[0] = 0;
    patternLarsonUP[1] = 0;
    patternLarsonUP[2] = 0;
    patternLarsonUP[3] = 0;
    patternLarsonUP[4] = 0;
    patternLarsonUP[5] = 0;
    patternLarsonUP[6] = 99; // Current Dot position (brightest)
    patternLarsonUP[7] = 10; // afterglow
    patternLarsonUP[8] = 0;
    patternLarsonUP[9] = 0;
    patternLarsonUP[10] = 0;
    patternLarsonUP[11] = 0;
    patternLarsonUP[12] = 0;
    patternLarsonUP[13] = 0;
    patternLarsonUP[14] = 0;
//    patternLarsonUP[15] = 0;

    patternLarsonDOWN[0] = 10;
    patternLarsonDOWN[1] = 99;
    patternLarsonDOWN[2] = 0;
    patternLarsonDOWN[3] = 0;
    patternLarsonDOWN[4] = 0;
    patternLarsonDOWN[5] = 0;
    patternLarsonDOWN[6] = 0;
    patternLarsonDOWN[7] = 0;
    patternLarsonDOWN[8] = 0;
    patternLarsonDOWN[9] = 0;
    patternLarsonDOWN[10] = 0;
    patternLarsonDOWN[11] = 0;
    patternLarsonDOWN[12] = 0;
    patternLarsonDOWN[13] = 0;
    patternLarsonDOWN[14] = 0;
//    patternLarsonDOWN[15] = 0;
}

void handlePWM(void) {
    duty++; // % of duty cycle completed

    if (brightnessLEDS[0] > 0) {
        brightnessLEDS[0]--;
        PORTAbits.RA6 = 0;
    } else {
        PORTAbits.RA6 = 1;
    }
    if (brightnessLEDS[1] > 0) {
        brightnessLEDS[1]--;
        PORTAbits.RA7 = 0;
    } else {
        PORTAbits.RA7 = 1;
    }
    if (brightnessLEDS[2] > 0) {
        brightnessLEDS[2]--;
        PORTAbits.RA0 = 0;
    } else {
        PORTAbits.RA0 = 1;
    }
    if (brightnessLEDS[3] > 0) {
        brightnessLEDS[3]--;
        PORTAbits.RA1 = 0;
    } else {
        PORTAbits.RA1 = 1;
    }
    if (brightnessLEDS[4] > 0) {
        brightnessLEDS[4]--;
        PORTAbits.RA2 = 0;
    } else {
        PORTAbits.RA2 = 1;
    }
    if (brightnessLEDS[5] > 0) {
        brightnessLEDS[5]--;
        PORTAbits.RA3 = 0;
    } else {
        PORTAbits.RA3 = 1;
    }
    if (brightnessLEDS[6] > 0) {
        brightnessLEDS[6]--;
        PORTAbits.RA4 = 0;
    } else {
        PORTAbits.RA4 = 1;
    }
    if (brightnessLEDS[7] > 0) {
        brightnessLEDS[7]--;
        PORTBbits.RB0 = 0;
    } else {
        PORTBbits.RB0 = 1;
    }
    if (brightnessLEDS[8] > 0) {
        brightnessLEDS[8]--;
        PORTBbits.RB1 = 0;
    } else {
        PORTBbits.RB1 = 1;
    }
    if (brightnessLEDS[9] > 0) {
        brightnessLEDS[9]--;
        PORTBbits.RB2 = 0;
    } else {
        PORTBbits.RB2 = 1;
    }
    if (brightnessLEDS[10] > 0) {
        brightnessLEDS[10]--;
        PORTBbits.RB3 = 0;
    } else {
        PORTBbits.RB3 = 1;
    }
    if (brightnessLEDS[11] > 0) {
        brightnessLEDS[11]--;
        PORTBbits.RB5 = 0;
    } else {
        PORTBbits.RB5 = 1;
    }
    if (brightnessLEDS[12] > 0) {
        brightnessLEDS[12]--;
        PORTBbits.RB4 = 0;
    } else {
        PORTBbits.RB4 = 1;
    }
    if (brightnessLEDS[13] > 0) {
        brightnessLEDS[13]--;
        PORTBbits.RB6 = 1;
    } else {
        PORTBbits.RB6 = 0;
    }
    if (brightnessLEDS[14] > 0) {
        brightnessLEDS[14]--;
        PORTBbits.RB7 = 1;
    } else {
        PORTBbits.RB7 = 0;
    }
}

void setupCountPattern(void) {              //cycle arond the perimeter of the heart.
    if (ms100Counter > pinCount - 1) {
        ms100Counter = 0;
    }
    for (char i = 0; i < pinCount; i++) {
        if (i == ms100Counter) {
            patternCurrent[i] = pwmMax;
        } else {
            patternCurrent[i] = 0;
        }
    }
}

void setupLarsonPattern(void) {
    //char offset = 0;
    char index = 0;
    if (ms100Counter == 1) {
        offset++;
        ms100Counter = 0;
    }
    if (offset == (pinCount - 1)) { // 7 for Larson scanner mode, will be 8 for other modes!

        offset = 0;
        if (direction == DOWN) {
            direction = UP;
        } else {
            direction = DOWN;
        }
    }
    // need a switch here to select patterns
    if (direction == UP) {
        for (char i = 0; i < pinCount; i++) {
            index = i + offset;
            if (index > (pinCount - 1)) {
                index = index - pinCount;
            }
            patternCurrent[i] = patternLarsonUP[index];
        }
    }
    if (direction == DOWN) {
        for (char i = 0; i < pinCount; i++) {
            if (i < offset) {
                index = pinCount - (offset - i);
            } else {

                index = i - offset;
            }
            patternCurrent[i] = patternLarsonDOWN[index];
        }
    }
}

void setupChasePattern(void) {
    //char offset = 0;
    char index = 0;
    if (ms100Counter == 1) {
        offset++;
        ms100Counter = 0;
    }
    if (offset == pinCount) {
        offset = 0;
    }
    for (char i = 0; i < pinCount; i++) {
        index = i + offset;
        if (index > (pinCount - 1)) {
            index = index - pinCount;
        }
        patternCurrent[i] = patternLarsonUP[index];
    }
}

void clearPattern(void) {
    for (char i = 0; i < pinCount; i++) {
        patternCurrent[i] = 0;
    }
}

void setupAllFadePattern(void) {
    if (firstSetup == 0) {
        clearPattern();
        firstSetup = 1;
        direction = UP;
    }

    if (ms100Counter > 1) {
        ms100Counter = 0;

        if (direction == UP) {
            for (char i = 0; i < pinCount; i++) {
                patternCurrent[i] = patternCurrent[i] + 1;
            }
            if (patternCurrent[0] > 25) {
                direction = DOWN;
            }
        }
        if (direction == DOWN) {
            for (char i = 0; i < pinCount; i++) {
                patternCurrent[i] = patternCurrent[i] - 1;
            }
            if (patternCurrent[0] < 1) {
                direction = UP;
            }
        }
    }
}

void setupBrightPattern(void) {
    // Logic set in setupLevels()
}

void setupDimPattern(void) {
    // Logic set in setupLevels()
}

void setupBreatherPattern(void) {
    if (firstSetup == 0) {
        clearPattern();
        firstSetup = 1;
        direction = UP;
        //patternCurrent[0] = 25;
        //patternCurrent[14] = 25;
    }

    if (ms100Counter > 1) {
        ms100Counter = 0;
        if (direction == UP) {
            patternCurrent[1] = patternCurrent[1] + 1;
            patternCurrent[2] = patternCurrent[2] + 1;
            patternCurrent[3] = patternCurrent[3] + 1;
            patternCurrent[4] = patternCurrent[4] + 1;
            patternCurrent[5] = patternCurrent[5] + 1;
            patternCurrent[6] = patternCurrent[6] + 1;
            patternCurrent[6] = patternCurrent[7] + 1;
            patternCurrent[6] = patternCurrent[8] + 1;
            patternCurrent[6] = patternCurrent[9] + 1;
            patternCurrent[6] = patternCurrent[10] + 1;
            patternCurrent[6] = patternCurrent[11] + 1;
            patternCurrent[6] = patternCurrent[12] + 1;
            patternCurrent[6] = patternCurrent[13] + 1;
            patternCurrent[6] = patternCurrent[14] + 1;
            if (patternCurrent[1] > 25) {
                direction = DOWN;
            }
        }
        if (direction == DOWN) {
            patternCurrent[1] = patternCurrent[1] - 1;
            patternCurrent[2] = patternCurrent[2] - 1;
            patternCurrent[3] = patternCurrent[3] - 1;
            patternCurrent[4] = patternCurrent[4] - 1;
            patternCurrent[5] = patternCurrent[5] - 1;
            patternCurrent[6] = patternCurrent[6] - 1;
            patternCurrent[6] = patternCurrent[7] - 1;
            patternCurrent[6] = patternCurrent[8] - 1;
            patternCurrent[6] = patternCurrent[9] - 1;
            patternCurrent[6] = patternCurrent[10] - 1;
            patternCurrent[6] = patternCurrent[11] - 1;
            patternCurrent[6] = patternCurrent[12] - 1;
            patternCurrent[6] = patternCurrent[13] - 1;
            patternCurrent[6] = patternCurrent[14] - 1;
            if (patternCurrent[1] < 1) {
                direction = UP;
            }
        }
    }
}

//void setupHeartPulse(void){
//
//}

void setupLevels(void) {

    duty = 0;

    for (char i = 0; i < pinCount; i++) {
        brightnessLEDS[i] = patternCurrent[i];
    }

    if (mode == flicker) {
        if (rand() > 0x3FFF) { //  Add flicker - randomly turn all leds off
            for (char i = 0; i < pinCount; i++) {
                brightnessLEDS[i] = brightnessLEDS[i] >> 2;
            }
        }
    }
    if (mode == bright) {
        for (char i = 0; i < pinCount; i++) {
            brightnessLEDS[i] = 99;
        }
    }
    if (mode == dim) {
        for (char i = 0; i < pinCount; i++) {
            brightnessLEDS[i] = 10;
        }
    }
}

void debounce(char test, char *state, char *counter) {
    if ((*state) != test) {
        (*counter)++;
        if ((*counter) >= MAX_DEBOUNCE_COUNT) {
            (*counter) = 0;
            (*state) = test;
        }
    } else {
        (*counter) = 0;
    }
}


