/* 
 * File:   Digital Heart.c
 * Author: Simon
 *
 * Created on 17 September 2015, 4:37 PM
 */

#include <stdio.h>
#include <stdlib.h>
//#include "PIC18F88.H"													// CHECK THIS IN DATASHEET.  WHAT 0x0004 ???
#include <xc.h>
//#include <plib.h>
//#include <adc.h>
#include <stdint.h>

#define MAX_DEBOUNCE_COUNT 	50			// How many times do we need the changed state

// Register: CMCON
//extern volatile unsigned char           CMCON               @ 0xFB4;


// DEFINE FUNCTION PROTOTYPES
void InitialiseHardware (void);
void InitialiseGlobals(void);
void debounce(char test, char *state, char *counter);

// DEFINE PINOUTS
#define LED_1   PORTAbits.RA6
#define LED_2   PORTAbits.RA7
#define LED_3   PORTAbits.RA0
#define LED_4   PORTAbits.RA1
#define LED_5   PORTAbits.RA2
#define LED_6   PORTAbits.RA3
#define LED_7   PORTAbits.RA4
#define LED_8   PORTBbits.RB0
#define LED_9   PORTBbits.RB1
#define LED_10  PORTBbits.RB2
#define LED_11  PORTBbits.RB3
#define LED_12  PORTBbits.RB5
#define LED_13  PORTBbits.RB4
#define LED_14  PORTBbits.RB6
#define LED_15  PORTBbits.RB7

#define BUTTON1     PORTAbits.RA5

#define NumInputs   1               // Only 1 input for this project.


// DEFINE GLOBALS
unsigned int Tms =0;

char FSRTemp;
char T1ms;						// 1 millisecond counter
char T10ms;						// 10's millisecond counter
char T100ms;						// 100's millisecond counter

char blink;

char StartButtonState;
char StartButtonPrev;
char StartButtonCounter;

uint16_t    TIMERS[4];                                  // 4 Timers for 4 LED modes
char        INPUTS_RAW[1];                              // Only 1 button to check
char        INPUTS_STATE[1];
uint16_t    OUTPUTS[4];
char	DebounceCounters[1];

char 	LoopCounter;


/*
 *
 */

void interrupt isr()
{
    if(PIR1bits.TMR2IF == 1){
        Tms ++;
        if (Tms==1000){
            Tms=0;
        }
        //reset the interrupt flag
    PIR1bits.TMR2IF = 0;
    }
}

void main(void) {

int i = 0;
int temp = 0;

char * PORTAPTR = &PORTA;


InitialiseHardware();
InitialiseGlobals();

	while (1) {
            temp = PORTA;
            for(i=0; i<NumInputs; i++){
		INPUTS_RAW[i]=temp&0x01;
		temp = temp >> 1;
		debounce(INPUTS_RAW[i], &INPUTS_STATE[i], &DebounceCounters[i]);
		}
            PORTA = 0xF0;
            PORTB = 0x01;
            *PORTAPTR = 0xF0;
            *(PORTAPTR + 1) = 0x01;
	}
}

void InitialiseHardware(void) {

    TRISA  = 0b00100000; 				// PORTA (0 = OUTPUT), RA5 = input button
    PORTA  = 0b00000000;				// Initialise PORTA
    TRISB  = 0b00000000;                                // PORTB (0 = OUTPUT)
    PORTB  = 0b00000000;				// Initialise PORTB
    OPTION_REG = 0b10001000;   				// No weak pull ups, prescaler assigned to WDT											(checked ok)
    INTCON = 0b11000000;				// TMR2 used to provide 1ms ticks.														(checked ok)
    CMCON  = 0b00000000;				// 														(checked ok)
    PCON   = 0b00000000;				// 													(checked ok)

    OSCCON = 0b01101100;				// 4MHz internal oscillator

    T2CON  = 0b00010101;				// TMR2 on, prescale = 1:4, and postscale = 1:2  (8us ticks with 4MHz oscillator) 		(check this for 8MHz)
    PIE1   = 0b00000010;				// Bit 1 enables TMR2 = PR2 interface
    PIR1   = 0b00000000;				// Read this to see if TMR2 = PR2 flag is set
    PR2 = 250;						// TMR2 match value, for 2ms ticks

    //ANSEL 	= 0x00;					// Select AN0
}

void InitialiseGlobals(void) {
	int i = 0;

	T1ms = 0;							// Reset Timers
	T10ms = 0;
	T100ms = 0;
//	SecondsFlag=0;
	for(i=0;i<4;i++){
		INPUTS_RAW[i]=0;
		INPUTS_STATE[i]=1;
		OUTPUTS[i]=0;
	}
	LoopCounter=0;
/*	TIMERS[0] = LIGHTS_RUNTIME;
	TIMERS[1] = DOOR1_RUNTIME;
	TIMERS[2] = DOOR2_RUNTIME;
 */
}

void debounce(char test, char *state, char *counter) {
	if ((*state) != test) {
   	(*counter)++;
		if ((*counter) >= MAX_DEBOUNCE_COUNT) {
			(*counter) = 0;
			(*state) = test;
		}
	} else {
		(*counter) = 0;
	}
}



