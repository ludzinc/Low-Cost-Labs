/* 
 * File:   newmain.c
 * Author: Simon
 *
 * Created on 27 July 2016, 11:12 PM
 * NOTE:
 * typedef uint8_t  BYTE;
 * typedef uint32_t DWORD;
 * typedef int32_t  LONG;
 * typedef uint16_t WORD;
 */

#include <stdio.h>
#include <stdlib.h>
#include <pic16f648a.h>
#include <xc.h>
#include <stdint.h>

// CONFIG
#pragma config FOSC = INTOSCIO  // Oscillator Selection bits (INTOSC oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = ON       // Power-up Timer Enable bit (PWRT enabled)
#pragma config MCLRE = OFF      // RA5/MCLR/VPP Pin Function Select bit (RA5/MCLR/VPP pin function is digital input, MCLR internally tied to VDD)
#pragma config BOREN = OFF      // Brown-out Detect Enable bit (BOD enabled)
#pragma config LVP = OFF        // Low-Voltage Programming Enable bit (RB4/PGM pin has digital I/O function, HV on MCLR must be used for programming)
#pragma config CPD = OFF        // Data EE Memory Code Protection bit (Data memory code protection off)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

#define _XTAL_FREQ = 4000000;

// macros for LED state
#define ON 1
#define OFF 0
#define UP 1
#define DOWN 0
#define pinCount 8
#define pwmMax 100      // instead of HW PWM's "255" levels, we get 100

// variables for pattern timing - will need to deal with overflow from 255 to 0
uint8_t currentMillis = 0;
uint8_t previousMillis = 0;
uint8_t millisInterval = 5;
// LED fading (multiples of milliseconds
uint8_t fadeIncrement = 5;
// Set staring position of LEDs
uint8_t larsonStatus = 0x80; //0b1000.0000
// bit mask for maximum scan value
uint8_t larsonMax = 0x80;
// arbitrary starting direction
uint8_t direction = DOWN;

// variables for software PWM
unsigned long currentMicros = 0;
unsigned long previousMicros = 0;
unsigned long microInterval = 10;


// typedef for properties of each sw pwm pin

typedef struct pwmPins {
    int pin;
    int pwmValue;
    int pinState;
    int pwmTickCount;
} pwmPin;
// create the sw pwm pins
const char pins[pinCount] = {1, 2, 3, 4, 5, 6, 7, 8};
// an array of Software PWM Pins
pwmPin myPWMpins[pinCount];


uint8_t msCounter = 0;
uint8_t ms10Counter = 0;
uint8_t sCounter = 0;
uint8_t brightness = 0;
uint8_t currentBrightness = 0;
uint8_t duty = 0;

void setup(void);
void setPin(int);
void clearPin(int);
void setupPWMpins(void);
void handlePWM(void);
void handleLEDs(void);

void interrupt Timer0_ISR(void) {
    if (T0IE && T0IF) //are TMR0 interrupts enabled and
        //is the TMR0 interrupt flag set?
    {
        TMR0 = 5; // sets verflow to happen in 250 more ticks for an even 1ms interrupt
        T0IF = 0; //TMR0 interrupt flag must be cleared in software
        //to allow subsequent interrupts
        ++msCounter; // overflows at 255
    }
}

/*
 * 
 */
void main(void) {

    setup();

    msCounter = 0;
    while (1) {
        if (msCounter >= millisInterval) {
            msCounter = 0;
            handlePWM();
        }
//        PORTBbits.RB0 = 1;
//        handleLEDs();
//        PORTBbits.RB0 = 0;
    }
}

void setup(void) {
    //SETUP IO PORTS
    TRISA = 0x00; // All PORTA pins are outputs
    CMCON = 0x07; // Comparators off, allows digital IO on RA[0..3]
    TRISB = 0x00; // RB0 = input, all other pins are outputs.
    PORTA = 0x00;
    PORTB = 0x00;
    //SET UP OPTION REGISTER
    OPTION_REG = 0x81; // Enable weak pullups PORTB, 1:4 prescaler TMR0 (4us ticks)
    //ENABLE INTERRUPTS
    INTCON = 0xA0; // Global Interrupts Enabled (GIE), TMR0 Overflow Interrupt Enabled (T0IE)

    setupPWMpins();

    //    myPWMpins[0].pwmValue = 5;
    //    myPWMpins[1].pwmValue = 10;
    //    myPWMpins[2].pwmValue = 15;
    //    myPWMpins[3].pwmValue = 20;
    //    myPWMpins[4].pwmValue = 25;
    myPWMpins[5].pwmValue = 5;
    myPWMpins[6].pwmValue = 25;
    //      myPWMpins[7].pwmValue = 100;
}

// ****************************************************************************************************
// setPIN
// sets required pin high to turn on LED of interest.
// LEDS are mapped as follows:
// PIN - LED MAP
// LED1 = RB1
// LED2 = RA3
// LED3 = RA2
// LED4 = RB3
// LED5 = RB4
// LED6 = RA0
// LED7 = RA1
// LED8 = RB5
// ****************************************************************************************************

void setPin(int pin) {
    switch (pin) {
        case 1:
            PORTBbits.RB1 = 1;
            break;
        case 2:
            PORTAbits.RA3 = 1;
            break;
        case 3:
            PORTAbits.RA2 = 1;
            break;
        case 4:
            PORTBbits.RB3 = 1;
            break;
        case 5:
            PORTBbits.RB4 = 1;
            break;
        case 6:
            PORTAbits.RA0 = 1;
            break;
        case 7:
            PORTAbits.RA1 = 1;
            break;
        case 8:
            PORTBbits.RB5 = 1;
            break;
        default:
            break;
    }
}
// ****************************************************************************************************
// clearPIN
// sets required pin low to turn off LED of interest.
// LEDS are mapped as follows:
// PIN - LED MAP
// LED1 = RB1
// LED2 = RA2
// LED3 = RA3
// LED4 = RB3
// LED5 = RB4
// LED6 = RA0
// LED7 = RA1
// LED8 = RB5
// ****************************************************************************************************

void clearPin(int pin) {
    switch (pin) {
        case 1:
            PORTBbits.RB1 = 0;
            break;
        case 2:
            PORTAbits.RA3 = 0;
            break;
        case 3:
            PORTAbits.RA2 = 0;
            break;
        case 4:
            PORTBbits.RB3 = 0;
            break;
        case 5:
            PORTBbits.RB4 = 0;
            break;
        case 6:
            PORTAbits.RA0 = 0;
            break;
        case 7:
            PORTAbits.RA1 = 0;
            break;
        case 8:
            PORTBbits.RB5 = 0;
            break;
        default:
            break;
    }
}

void setupPWMpins(void) {
    for (int index = 0; index < pinCount; index++) {
        myPWMpins[index].pin = pins[index]; // connect a myPWMpin to an actual pin
        myPWMpins[index].pwmValue = 0; // start with all LEDs off
        myPWMpins[index].pinState = OFF; // doesn't matter ON or OFF
        myPWMpins[index].pwmTickCount = 0; // set the counter to 0
    }
}
// call this periodically when ms coutner is correct.....

void handlePWM(void) {
    for (int index = 0; index < pinCount; index++) {
        // each pin has its own tickCounter
        if (myPWMpins[index].pwmTickCount < pwmMax) {
            myPWMpins[index].pwmTickCount++;
        } else {
            myPWMpins[index].pwmTickCount = 0;
        }
        // see if we hit the desired on percentage
        if (myPWMpins[index].pwmTickCount < myPWMpins[index].pwmValue) {
            myPWMpins[index].pinState = ON;
            setPin(index + 1);
        } else {
            myPWMpins[index].pinState = OFF;
            clearPin(index + 1);
        }
    }
}

void handleLEDs(void) {
    for (int index = 0; index < pinCount; index++) {

        if (myPWMpins[index].pinState == ON) {
            setPin(index + 1);
        } else {
            clearPin(index + 1);
        }

    }
}